'use client'

import { useRef, useMemo, useEffect } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import { Html } from '@react-three/drei'
import * as THREE from 'three'
import { useUniverseStore } from '@/store/useUniverseStore'

function PlanetSurface({ planetId, planetSize }: { planetId: string; planetSize: number }) {
  const meshRef = useRef<THREE.Mesh>(null)
  const cloudsRef = useRef<THREE.Mesh>(null)
  const atmosphereRef = useRef<THREE.Mesh>(null)

  const surfaceTexture = useMemo(() => {
    const canvas = document.createElement('canvas')
    canvas.width = 2048
    canvas.height = 1024
    const ctx = canvas.getContext('2d')!

    switch (planetId) {
      case 'earth': {
        // Ocean base
        ctx.fillStyle = '#1a5276'
        ctx.fillRect(0, 0, 2048, 1024)

        // Continents
        const drawContinent = (x: number, y: number, w: number, h: number, color: string) => {
          ctx.fillStyle = color
          ctx.beginPath()
          ctx.ellipse(x, y, w, h, Math.random() * 0.5, 0, Math.PI * 2)
          ctx.fill()
          for (let i = 0; i < 5; i++) {
            ctx.beginPath()
            ctx.ellipse(
              x + (Math.random() - 0.5) * w * 1.5,
              y + (Math.random() - 0.5) * h * 1.5,
              w * (0.3 + Math.random() * 0.5),
              h * (0.3 + Math.random() * 0.5),
              Math.random() * Math.PI,
              0,
              Math.PI * 2
            )
            ctx.fill()
          }
        }

        drawContinent(400, 300, 150, 200, '#2d6a2d')
        drawContinent(900, 350, 250, 200, '#3d7a3d')
        drawContinent(1200, 400, 180, 250, '#4d8a4d')
        drawContinent(1500, 300, 200, 180, '#3d7a3d')
        drawContinent(700, 600, 120, 150, '#5d9a5d')
        drawContinent(1800, 500, 180, 220, '#3d7a3d')

        // Ice caps
        ctx.fillStyle = '#ffffff'
        ctx.fillRect(0, 0, 2048, 60)
        ctx.fillRect(0, 964, 2048, 60)

        break
      }
      case 'mars': {
        ctx.fillStyle = '#8b3a1a'
        ctx.fillRect(0, 0, 2048, 1024)

        for (let i = 0; i < 200; i++) {
          const x = Math.random() * 2048
          const y = Math.random() * 1024
          const r = 5 + Math.random() * 40
          ctx.fillStyle = `rgb(${120 + Math.random() * 60}, ${30 + Math.random() * 40}, ${10 + Math.random() * 20})`
          ctx.beginPath()
          ctx.arc(x, y, r, 0, Math.PI * 2)
          ctx.fill()
        }

        // Olympus Mons
        ctx.fillStyle = '#6b2a0a'
        ctx.beginPath()
        ctx.arc(600, 300, 80, 0, Math.PI * 2)
        ctx.fill()
        ctx.fillStyle = '#9b4a2a'
        ctx.beginPath()
        ctx.arc(600, 300, 50, 0, Math.PI * 2)
        ctx.fill()

        // Valles Marineris
        ctx.strokeStyle = '#4a1a0a'
        ctx.lineWidth = 8
        ctx.beginPath()
        ctx.moveTo(800, 500)
        ctx.lineTo(1300, 520)
        ctx.stroke()

        // Polar ice caps
        ctx.fillStyle = '#d4c4b4'
        ctx.fillRect(0, 0, 2048, 40)
        ctx.fillRect(0, 984, 2048, 40)

        break
      }
      case 'jupiter': {
        // Banded structure
        const bands = [
          '#c88b3a', '#a06a2a', '#d4a35a', '#8a5a1a',
          '#c88b3a', '#b07a3a', '#d4a35a', '#9a6a2a',
          '#c88b3a', '#a06a2a', '#d4a35a', '#8a5a1a',
        ]
        const bandHeight = 1024 / bands.length
        bands.forEach((color, i) => {
          ctx.fillStyle = color
          ctx.fillRect(0, i * bandHeight, 2048, bandHeight)
        })

        // Great Red Spot
        ctx.fillStyle = '#c44a2a'
        ctx.beginPath()
        ctx.ellipse(1400, 550, 100, 60, 0, 0, Math.PI * 2)
        ctx.fill()
        ctx.fillStyle = '#d45a3a'
        ctx.beginPath()
        ctx.ellipse(1400, 550, 60, 35, 0, 0, Math.PI * 2)
        ctx.fill()

        // Storms
        for (let i = 0; i < 30; i++) {
          ctx.fillStyle = `rgba(${180 + Math.random() * 60}, ${100 + Math.random() * 60}, ${30 + Math.random() * 40}, 0.4)`
          ctx.beginPath()
          ctx.ellipse(
            Math.random() * 2048,
            Math.random() * 1024,
            20 + Math.random() * 40,
            10 + Math.random() * 20,
            0, 0, Math.PI * 2
          )
          ctx.fill()
        }

        break
      }
      case 'saturn': {
        const bands = [
          '#e8d5a3', '#d4c598', '#f0e0b0', '#c8b588',
          '#e8d5a3', '#d4c598', '#f0e0b0', '#c8b588',
        ]
        const bandHeight = 1024 / bands.length
        bands.forEach((color, i) => {
          ctx.fillStyle = color
          ctx.fillRect(0, i * bandHeight, 2048, bandHeight)
        })
        break
      }
      default: {
        ctx.fillStyle = '#555555'
        ctx.fillRect(0, 0, 2048, 1024)
        for (let i = 0; i < 100; i++) {
          ctx.fillStyle = `rgb(${60 + Math.random() * 80}, ${60 + Math.random() * 80}, ${60 + Math.random() * 80})`
          ctx.beginPath()
          ctx.arc(Math.random() * 2048, Math.random() * 1024, 5 + Math.random() * 30, 0, Math.PI * 2)
          ctx.fill()
        }
      }
    }

    return new THREE.CanvasTexture(canvas)
  }, [planetId])

  const cloudTexture = useMemo(() => {
    if (planetId !== 'earth') return null
    const canvas = document.createElement('canvas')
    canvas.width = 2048
    canvas.height = 1024
    const ctx = canvas.getContext('2d')!

    ctx.clearRect(0, 0, 2048, 1024)

    for (let i = 0; i < 150; i++) {
      const x = Math.random() * 2048
      const y = Math.random() * 1024
      ctx.fillStyle = `rgba(255, 255, 255, ${0.1 + Math.random() * 0.3})`
      ctx.beginPath()
      ctx.ellipse(x, y, 30 + Math.random() * 80, 10 + Math.random() * 30, Math.random() * Math.PI, 0, Math.PI * 2)
      ctx.fill()
    }

    return new THREE.CanvasTexture(canvas)
  }, [planetId])

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.y += 0.002
    }
    if (cloudsRef.current) {
      cloudsRef.current.rotation.y += 0.003
    }
    if (atmosphereRef.current) {
      atmosphereRef.current.rotation.y += 0.001
    }
  })

  return (
    <group>
      <mesh ref={meshRef}>
        <sphereGeometry args={[planetSize, 128, 128]} />
        <meshPhongMaterial
          map={surfaceTexture}
          shininess={25}
          specular="#333333"
        />
      </mesh>

      {cloudTexture && (
        <mesh ref={cloudsRef} scale={planetSize * 1.01}>
          <sphereGeometry args={[1, 64, 64]} />
          <meshPhongMaterial
            map={cloudTexture}
            transparent
            opacity={0.5}
            depthWrite={false}
          />
        </mesh>
      )}

      <mesh ref={atmosphereRef} scale={planetSize * 1.08}>
        <sphereGeometry args={[1, 64, 64]} />
        <meshBasicMaterial
          color={planetId === 'mars' ? '#d4724e' : planetId === 'earth' ? '#4a90d9' : '#8899aa'}
          transparent
          opacity={0.08}
          depthWrite={false}
          side={THREE.BackSide}
        />
      </mesh>
    </group>
  )
}

function SaturnRings({ planetSize }: { planetSize: number }) {
  const ref = useRef<THREE.Mesh>(null)

  const ringTexture = useMemo(() => {
    const canvas = document.createElement('canvas')
    canvas.width = 1024
    canvas.height = 64
    const ctx = canvas.getContext('2d')!

    for (let x = 0; x < 1024; x++) {
      const t = x / 1024
      const alpha = Math.sin(t * Math.PI) * 0.7
      const gap1 = Math.abs(t - 0.4) < 0.02 ? 0 : 1
      const gap2 = Math.abs(t - 0.65) < 0.015 ? 0 : 1
      const brightness = 160 + Math.random() * 60
      ctx.fillStyle = `rgba(${brightness}, ${brightness - 20}, ${brightness - 50}, ${alpha * gap1 * gap2})`
      ctx.fillRect(x, 0, 1, 64)
    }

    return new THREE.CanvasTexture(canvas)
  }, [])

  return (
    <mesh ref={ref} rotation={[Math.PI / 2.5, 0, 0]}>
      <ringGeometry args={[planetSize * 1.4, planetSize * 2.5, 128]} />
      <meshBasicMaterial
        map={ringTexture}
        transparent
        opacity={0.7}
        side={THREE.DoubleSide}
        depthWrite={false}
      />
    </mesh>
  )
}

function JupiterMoons({ planetSize }: { planetSize: number }) {
  const moons = useMemo(() => [
    { name: 'Io', distance: planetSize + 2, speed: 1.2, size: 0.15, color: '#e8d44d' },
    { name: 'Europa', distance: planetSize + 3, speed: 0.8, size: 0.12, color: '#c8b888' },
    { name: 'Ganymede', distance: planetSize + 4.2, speed: 0.5, size: 0.2, color: '#a0988a' },
    { name: 'Callisto', distance: planetSize + 5.5, speed: 0.3, size: 0.18, color: '#6a6258' },
  ], [planetSize])

  return (
    <group>
      {moons.map((moon, i) => (
        <JupiterMoon key={i} moon={moon} />
      ))}
    </group>
  )
}

function JupiterMoon({ moon }: { moon: { name: string; distance: number; speed: number; size: number; color: string } }) {
  const ref = useRef<THREE.Mesh>(null)

  useFrame((state) => {
    if (ref.current) {
      const t = state.clock.elapsedTime * moon.speed
      ref.current.position.x = Math.cos(t) * moon.distance
      ref.current.position.z = Math.sin(t) * moon.distance
    }
  })

  return (
    <mesh ref={ref}>
      <sphereGeometry args={[moon.size, 16, 16]} />
      <meshPhongMaterial color={moon.color} />
    </mesh>
  )
}

export function PlanetView() {
  const { selectedPlanet } = useUniverseStore()
  const groupRef = useRef<THREE.Group>(null)

  if (!selectedPlanet) return null

  const planetSize = 5

  return (
    <group ref={groupRef}>
      <ambientLight intensity={0.2} />
      <directionalLight
        position={[20, 10, 15]}
        intensity={1.5}
        color="#fff5e0"
      />
      <pointLight position={[-20, -10, -15]} intensity={0.3} color="#4466aa" />

      <PlanetSurface planetId={selectedPlanet.id} planetSize={planetSize} />

      {selectedPlanet.rings && <SaturnRings planetSize={planetSize} />}
      {(selectedPlanet.id === 'jupiter') && <JupiterMoons planetSize={planetSize} />}
    </group>
  )
}
