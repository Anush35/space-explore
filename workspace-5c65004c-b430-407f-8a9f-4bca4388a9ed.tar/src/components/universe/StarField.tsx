'use client'

import { useRef, useMemo, useCallback } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'

const STAR_COUNT = 8000
const NEBULA_COUNT = 200

export function StarField() {
  const meshRef = useRef<THREE.Points>(null)

  const [positions, colors, sizes] = useMemo(() => {
    const pos = new Float32Array(STAR_COUNT * 3)
    const col = new Float32Array(STAR_COUNT * 3)
    const siz = new Float32Array(STAR_COUNT)

    for (let i = 0; i < STAR_COUNT; i++) {
      const i3 = i * 3
      const radius = 200 + Math.random() * 800
      const theta = Math.random() * Math.PI * 2
      const phi = Math.acos(2 * Math.random() - 1)

      pos[i3] = radius * Math.sin(phi) * Math.cos(theta)
      pos[i3 + 1] = radius * Math.sin(phi) * Math.sin(theta)
      pos[i3 + 2] = radius * Math.cos(phi)

      const colorChoice = Math.random()
      if (colorChoice < 0.3) {
        col[i3] = 0.8 + Math.random() * 0.2
        col[i3 + 1] = 0.85 + Math.random() * 0.15
        col[i3 + 2] = 1.0
      } else if (colorChoice < 0.6) {
        col[i3] = 1.0
        col[i3 + 1] = 0.95 + Math.random() * 0.05
        col[i3 + 2] = 0.8 + Math.random() * 0.2
      } else {
        col[i3] = 1.0
        col[i3 + 1] = 1.0
        col[i3 + 2] = 1.0
      }

      siz[i] = 0.5 + Math.random() * 2.5
    }

    return [pos, col, siz]
  }, [])

  useFrame((state) => {
    if (!meshRef.current) return
    const time = state.clock.elapsedTime
    const geometry = meshRef.current.geometry
    const sizeAttr = geometry.getAttribute('size') as THREE.BufferAttribute
    if (sizeAttr) {
      for (let i = 0; i < STAR_COUNT; i++) {
        sizeAttr.array[i] = sizes[i] * (0.8 + 0.2 * Math.sin(time * 0.5 + i * 0.1))
      }
      sizeAttr.needsUpdate = true
    }
    meshRef.current.rotation.y = time * 0.002
  })

  const starMaterial = useMemo(() => {
    return new THREE.ShaderMaterial({
      uniforms: {
        time: { value: 0 },
      },
      vertexShader: `
        attribute float size;
        varying vec3 vColor;
        varying float vSize;
        void main() {
          vColor = color;
          vSize = size;
          vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
          gl_PointSize = size * (300.0 / -mvPosition.z);
          gl_Position = projectionMatrix * mvPosition;
        }
      `,
      fragmentShader: `
        varying vec3 vColor;
        varying float vSize;
        void main() {
          float dist = length(gl_PointCoord - vec2(0.5));
          if (dist > 0.5) discard;
          float alpha = 1.0 - smoothstep(0.0, 0.5, dist);
          float glow = exp(-dist * 4.0) * 0.5;
          gl_FragColor = vec4(vColor * (1.0 + glow), alpha);
        }
      `,
      transparent: true,
      vertexColors: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    })
  }, [])

  const materialRef = useRef(starMaterial)
  materialRef.current = starMaterial

  useFrame((state) => {
    materialRef.current.uniforms.time.value = state.clock.elapsedTime
  })

  return (
    <points ref={meshRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={STAR_COUNT}
          array={positions}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-color"
          count={STAR_COUNT}
          array={colors}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-size"
          count={STAR_COUNT}
          array={sizes}
          itemSize={1}
        />
      </bufferGeometry>
      <primitive object={starMaterial} attach="material" />
    </points>
  )
}

export function NebulaClouds() {
  const groupRef = useRef<THREE.Group>(null)

  const nebulae = useMemo(() => {
    const items = []
    for (let i = 0; i < NEBULA_COUNT; i++) {
      const radius = 150 + Math.random() * 500
      const theta = Math.random() * Math.PI * 2
      const phi = Math.acos(2 * Math.random() - 1)

      const x = radius * Math.sin(phi) * Math.cos(theta)
      const y = radius * Math.sin(phi) * Math.sin(theta)
      const z = radius * Math.cos(phi)

      const scale = 20 + Math.random() * 60

      const colorChoice = Math.random()
      let color: string
      if (colorChoice < 0.25) color = '#4a1a8a'
      else if (colorChoice < 0.5) color = '#1a3a8a'
      else if (colorChoice < 0.75) color = '#8a1a4a'
      else color = '#1a6a8a'

      items.push({
        position: [x, y, z] as [number, number, number],
        scale,
        color,
        opacity: 0.03 + Math.random() * 0.06,
        rotationSpeed: (Math.random() - 0.5) * 0.001,
      })
    }
    return items
  }, [])

  useFrame((state) => {
    if (!groupRef.current) return
    const time = state.clock.elapsedTime
    groupRef.current.rotation.y = time * 0.001
  })

  return (
    <group ref={groupRef}>
      {nebulae.map((nebula, i) => (
        <mesh key={i} position={nebula.position} scale={nebula.scale}>
          <sphereGeometry args={[1, 8, 8]} />
          <meshBasicMaterial
            color={nebula.color}
            transparent
            opacity={nebula.opacity}
            depthWrite={false}
            blending={THREE.AdditiveBlending}
          />
        </mesh>
      ))}
    </group>
  )
}

export function MilkyWay() {
  const meshRef = useRef<THREE.Mesh>(null)

  const milkyWayTexture = useMemo(() => {
    const canvas = document.createElement('canvas')
    canvas.width = 1024
    canvas.height = 1024
    const ctx = canvas.getContext('2d')!

    const gradient = ctx.createRadialGradient(512, 512, 0, 512, 512, 512)
    gradient.addColorStop(0, 'rgba(180, 160, 220, 0.4)')
    gradient.addColorStop(0.2, 'rgba(120, 100, 180, 0.25)')
    gradient.addColorStop(0.4, 'rgba(80, 60, 140, 0.15)')
    gradient.addColorStop(0.7, 'rgba(40, 30, 100, 0.05)')
    gradient.addColorStop(1, 'rgba(0, 0, 0, 0)')

    ctx.fillStyle = gradient
    ctx.fillRect(0, 0, 1024, 1024)

    for (let i = 0; i < 3000; i++) {
      const angle = Math.random() * Math.PI * 2
      const dist = Math.random() * 400 + 50
      const spread = (Math.random() - 0.5) * 80
      const x = 512 + Math.cos(angle) * dist + spread
      const y = 512 + Math.sin(angle) * dist + spread
      const brightness = 100 + Math.floor(Math.random() * 155)
      const size = 0.5 + Math.random() * 2
      ctx.fillStyle = `rgba(${brightness}, ${brightness - 20}, ${brightness + 30}, ${0.3 + Math.random() * 0.5})`
      ctx.beginPath()
      ctx.arc(x, y, size, 0, Math.PI * 2)
      ctx.fill()
    }

    const texture = new THREE.CanvasTexture(canvas)
    texture.needsUpdate = true
    return texture
  }, [])

  useFrame((state) => {
    if (!meshRef.current) return
    meshRef.current.rotation.z = state.clock.elapsedTime * 0.003
  })

  return (
    <mesh ref={meshRef} position={[0, 0, -300]} scale={[300, 300, 1]}>
      <planeGeometry args={[1, 1]} />
      <meshBasicMaterial
        map={milkyWayTexture}
        transparent
        opacity={0.6}
        depthWrite={false}
        blending={THREE.AdditiveBlending}
        side={THREE.DoubleSide}
      />
    </mesh>
  )
}

export function FloatingParticles() {
  const ref = useRef<THREE.Points>(null)
  const count = 500

  const positions = useMemo(() => {
    const pos = new Float32Array(count * 3)
    for (let i = 0; i < count; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 200
      pos[i * 3 + 1] = (Math.random() - 0.5) * 200
      pos[i * 3 + 2] = (Math.random() - 0.5) * 200
    }
    return pos
  }, [])

  useFrame((state) => {
    if (!ref.current) return
    const time = state.clock.elapsedTime
    ref.current.rotation.y = time * 0.01
    ref.current.rotation.x = Math.sin(time * 0.005) * 0.1
  })

  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={count}
          array={positions}
          itemSize={3}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.3}
        color="#88aaff"
        transparent
        opacity={0.4}
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </points>
  )
}

export function UniverseScene() {
  return (
    <group>
      <StarField />
      <NebulaClouds />
      <MilkyWay />
      <FloatingParticles />
      <ambientLight intensity={0.1} />
    </group>
  )
}
