'use client'

import { useRef, useEffect, useCallback, useMemo } from 'react'
import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { OrbitControls, Stars, PerspectiveCamera } from '@react-three/drei'
import * as THREE from 'three'
import gsap from 'gsap'
import { useUniverseStore, SceneType } from '@/store/useUniverseStore'
import { UniverseScene } from './StarField'
import { SolarSystem } from './SolarSystem'
import { PlanetView } from './PlanetView'
import { BlackHole } from './BlackHole'
import { ExoplanetSystem } from './ExoplanetSystem'
import { PostProcessingEffects, HyperspaceEffect } from './Effects'

function CameraController() {
  const { camera } = useThree()
  const { currentScene, isTransitioning, setTransitioning } = useUniverseStore()
  const targetPos = useRef(new THREE.Vector3(0, 5, 30))
  const targetLookAt = useRef(new THREE.Vector3(0, 0, 0))
  const mousePos = useRef({ x: 0, y: 0 })

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      mousePos.current.x = (e.clientX / window.innerWidth - 0.5) * 2
      mousePos.current.y = (e.clientY / window.innerHeight - 0.5) * 2
    }
    window.addEventListener('mousemove', handleMouseMove)
    return () => window.removeEventListener('mousemove', handleMouseMove)
  }, [])

  useEffect(() => {
    let newPos: [number, number, number]
    let newLookAt: [number, number, number]

    switch (currentScene) {
      case 'universe':
        newPos = [0, 5, 30]
        newLookAt = [0, 0, -50]
        break
      case 'solarSystem':
        newPos = [0, 30, 60]
        newLookAt = [0, 0, 0]
        break
      case 'planetView':
        newPos = [8, 3, 12]
        newLookAt = [0, 0, 0]
        break
      case 'blackHole':
        newPos = [0, 5, 25]
        newLookAt = [0, 0, 0]
        break
      case 'exoplanet':
        newPos = [0, 8, 30]
        newLookAt = [0, 0, 0]
        break
      default:
        newPos = [0, 5, 30]
        newLookAt = [0, 0, 0]
    }

    gsap.to(targetPos.current, {
      x: newPos[0],
      y: newPos[1],
      z: newPos[2],
      duration: 2.5,
      ease: 'power2.inOut',
      onUpdate: () => {
        camera.position.copy(targetPos.current)
      },
    })

    gsap.to(targetLookAt.current, {
      x: newLookAt[0],
      y: newLookAt[1],
      z: newLookAt[2],
      duration: 2.5,
      ease: 'power2.inOut',
    })

    setTimeout(() => setTransitioning(false), 2500)
  }, [currentScene, camera, setTransitioning])

  useFrame(() => {
    const mouseInfluence = 0.5
    const newX = camera.position.x + (mousePos.current.x * mouseInfluence - (camera.position.x - targetPos.current.x)) * 0.02
    const newY = camera.position.y + (-mousePos.current.y * mouseInfluence * 0.3 - (camera.position.y - targetPos.current.y)) * 0.02
    camera.position.set(newX, newY, camera.position.z)
    camera.lookAt(targetLookAt.current)
  })

  return null
}

function SceneContent() {
  const { currentScene, isTransitioning } = useUniverseStore()

  return (
    <>
      <PerspectiveCamera makeDefault fov={60} near={0.1} far={2000} />
      <CameraController />

      {/* Background stars always visible */}
      <Stars
        radius={800}
        depth={100}
        count={5000}
        factor={4}
        saturation={0.2}
        fade
        speed={0.5}
      />

      {/* Scene-specific content */}
      {currentScene === 'universe' && <UniverseScene />}
      {currentScene === 'solarSystem' && <SolarSystem />}
      {currentScene === 'planetView' && <PlanetView />}
      {currentScene === 'blackHole' && <BlackHole />}
      {currentScene === 'exoplanet' && <ExoplanetSystem />}

      {/* Hyperspace effect during transitions */}
      {isTransitioning && <HyperspaceEffect />}

      <PostProcessingEffects />

      <OrbitControls
        enablePan={true}
        enableZoom={true}
        enableRotate={true}
        zoomSpeed={0.5}
        rotateSpeed={0.3}
        minDistance={3}
        maxDistance={500}
        enableDamping
        dampingFactor={0.05}
      />
    </>
  )
}

export function UniverseCanvas() {
  return (
    <Canvas
      gl={{
        antialias: true,
        toneMapping: THREE.ACESFilmicToneMapping,
        toneMappingExposure: 1.2,
      }}
      style={{ position: 'fixed', top: 0, left: 0, width: '100%', height: '100%' }}
    >
      <color attach="background" args={['#000008']} />
      <fog attach="fog" args={['#000008', 200, 800]} />
      <SceneContent />
    </Canvas>
  )
}
