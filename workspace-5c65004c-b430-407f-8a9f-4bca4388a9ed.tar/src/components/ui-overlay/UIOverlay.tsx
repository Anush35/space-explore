'use client'

import { useState, useEffect, useSyncExternalStore } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useUniverseStore } from '@/store/useUniverseStore'
import { PLANETS, GALAXY_ZOOM_LEVELS } from '@/data/planets'

export function MainMenu() {
  const { currentScene, setScene, setTransitioning, showMenu, toggleMenu } = useUniverseStore()
  const mounted = useSyncExternalStore(
    () => () => {},
    () => true,
    () => false
  )

  if (!mounted) return null

  const handleExploreSolarSystem = () => {
    setTransitioning(true)
    setTimeout(() => setScene('solarSystem'), 300)
  }

  const handleBeginJourney = () => {
    setTransitioning(true)
    setTimeout(() => {
      setScene('solarSystem')
    }, 500)
  }

  const handleBlackHole = () => {
    setTransitioning(true)
    setTimeout(() => setScene('blackHole'), 300)
  }

  return (
    <AnimatePresence>
      {showMenu && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1 }}
          className="fixed inset-0 z-40 flex flex-col items-center justify-center pointer-events-none"
        >
          {/* Title */}
          {currentScene === 'universe' && (
            <motion.div
              initial={{ opacity: 0, y: -30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1.5, delay: 0.5 }}
              className="text-center mb-16"
            >
              <h1 className="text-6xl md:text-8xl font-extralight tracking-[0.3em] text-white/90 mb-2"
                style={{ fontFamily: 'var(--font-geist-sans)' }}
              >
                UNIVERSE
              </h1>
              <h2 className="text-3xl md:text-5xl font-extralight tracking-[0.5em] text-cyan-400/70"
                style={{ fontFamily: 'var(--font-geist-sans)' }}
              >
                EXPLORER
              </h2>
              <div className="mt-4 w-32 h-px bg-gradient-to-r from-transparent via-cyan-400/50 to-transparent mx-auto" />
            </motion.div>
          )}

          {/* Navigation buttons */}
          {currentScene === 'universe' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 1.5 }}
              className="flex flex-col gap-4 pointer-events-auto"
            >
              <button
                onClick={handleBeginJourney}
                className="group relative px-10 py-4 border border-cyan-400/30 rounded-lg text-cyan-300 text-lg tracking-widest uppercase overflow-hidden transition-all duration-500 hover:border-cyan-400/60 hover:shadow-[0_0_30px_rgba(0,200,255,0.15)]"
                style={{ fontFamily: 'var(--font-geist-sans)' }}
              >
                <span className="relative z-10">Begin Journey</span>
                <div className="absolute inset-0 bg-cyan-400/0 group-hover:bg-cyan-400/10 transition-all duration-500" />
                <div className="absolute inset-0 translate-x-[-100%] group-hover:translate-x-[100%] bg-gradient-to-r from-transparent via-cyan-400/20 to-transparent transition-transform duration-700" />
              </button>

              <button
                onClick={handleExploreSolarSystem}
                className="group relative px-10 py-4 border border-white/20 rounded-lg text-white/70 text-lg tracking-widest uppercase overflow-hidden transition-all duration-500 hover:border-white/40 hover:text-white hover:shadow-[0_0_20px_rgba(255,255,255,0.1)]"
                style={{ fontFamily: 'var(--font-geist-sans)' }}
              >
                <span className="relative z-10">Explore Solar System</span>
                <div className="absolute inset-0 bg-white/0 group-hover:bg-white/5 transition-all duration-500" />
              </button>

              <button
                onClick={handleBlackHole}
                className="group relative px-10 py-4 border border-purple-400/20 rounded-lg text-purple-300/70 text-lg tracking-widest uppercase overflow-hidden transition-all duration-500 hover:border-purple-400/40 hover:text-purple-300 hover:shadow-[0_0_20px_rgba(150,0,255,0.1)]"
                style={{ fontFamily: 'var(--font-geist-sans)' }}
              >
                <span className="relative z-10">Enter Black Hole</span>
                <div className="absolute inset-0 bg-purple-400/0 group-hover:bg-purple-400/5 transition-all duration-500" />
              </button>
            </motion.div>
          )}

          {/* Solar System Back Button */}
          {currentScene === 'solarSystem' && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1 }}
              className="absolute top-6 left-6 pointer-events-auto"
            >
              <button
                onClick={() => {
                  setTransitioning(true)
                  setTimeout(() => setScene('universe'), 300)
                }}
                className="group flex items-center gap-2 px-4 py-2 border border-white/20 rounded-lg text-white/60 text-sm tracking-wider uppercase hover:border-cyan-400/40 hover:text-cyan-300 transition-all duration-300 backdrop-blur-md bg-black/30"
              >
                <svg className="w-4 h-4 group-hover:-translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
                Back to Universe
              </button>
            </motion.div>
          )}

          {/* Planet View Back Button */}
          {(currentScene === 'planetView' || currentScene === 'blackHole' || currentScene === 'exoplanet') && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1 }}
              className="absolute top-6 left-6 pointer-events-auto"
            >
              <button
                onClick={() => {
                  setTransitioning(true)
                  setTimeout(() => setScene('solarSystem'), 300)
                }}
                className="group flex items-center gap-2 px-4 py-2 border border-white/20 rounded-lg text-white/60 text-sm tracking-wider uppercase hover:border-cyan-400/40 hover:text-cyan-300 transition-all duration-300 backdrop-blur-md bg-black/30"
              >
                <svg className="w-4 h-4 group-hover:-translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
                Back to Solar System
              </button>
            </motion.div>
          )}

          {/* Scene Label */}
          {currentScene !== 'universe' && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="absolute top-6 left-1/2 -translate-x-1/2"
            >
              <div className="px-6 py-2 border border-white/10 rounded-full text-white/50 text-xs tracking-[0.3em] uppercase backdrop-blur-md bg-black/20">
                {currentScene === 'solarSystem' ? 'Solar System' :
                  currentScene === 'planetView' ? 'Planet Exploration' :
                  currentScene === 'blackHole' ? 'Black Hole' :
                  currentScene === 'exoplanet' ? 'Exoplanet System' :
                  currentScene}
              </div>
            </motion.div>
          )}
        </motion.div>
      )}
    </AnimatePresence>
  )
}

export function PlanetInfoPanel() {
  const { selectedPlanet, showPlanetInfo, togglePlanetInfo } = useUniverseStore()

  if (!selectedPlanet || !showPlanetInfo) return null

  return (
    <motion.div
      initial={{ opacity: 0, x: 50 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 50 }}
      transition={{ duration: 0.5 }}
      className="fixed right-6 top-1/2 -translate-y-1/2 z-50 w-80 pointer-events-auto"
    >
      <div className="rounded-2xl border border-white/10 bg-black/40 backdrop-blur-xl p-6 shadow-2xl">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-light tracking-wider text-white/90">{selectedPlanet.name}</h3>
          <button
            onClick={togglePlanetInfo}
            className="text-white/40 hover:text-white/80 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="w-full h-px bg-gradient-to-r from-transparent via-cyan-400/30 to-transparent mb-4" />

        <p className="text-sm text-white/60 leading-relaxed mb-4">{selectedPlanet.description}</p>

        <div className="space-y-2">
          <h4 className="text-xs tracking-widest text-cyan-400/70 uppercase">Key Facts</h4>
          {selectedPlanet.facts.map((fact, i) => (
            <div key={i} className="flex items-start gap-2 text-xs text-white/50">
              <span className="text-cyan-400/50 mt-0.5">•</span>
              <span>{fact}</span>
            </div>
          ))}
        </div>

        <div className="mt-4 flex gap-2">
          <div className="flex-1 px-3 py-2 rounded-lg border border-white/10 bg-white/5 text-center">
            <div className="text-[10px] text-white/30 uppercase tracking-wider">Type</div>
            <div className="text-sm text-white/70 capitalize">{selectedPlanet.type}</div>
          </div>
          <div className="flex-1 px-3 py-2 rounded-lg border border-white/10 bg-white/5 text-center">
            <div className="text-[10px] text-white/30 uppercase tracking-wider">Size</div>
            <div className="text-sm text-white/70">{selectedPlanet.size.toFixed(1)}x</div>
          </div>
        </div>
      </div>
    </motion.div>
  )
}

export function HUD() {
  const { currentScene, selectedPlanet, showPlanetInfo, togglePlanetInfo, toggleSearch } = useUniverseStore()
  const [time, setTime] = useState('')

  useEffect(() => {
    const interval = setInterval(() => {
      setTime(new Date().toISOString().replace('T', ' ').substring(0, 19))
    }, 1000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="fixed inset-0 z-30 pointer-events-none">
      {/* Top-left: Time */}
      <div className="absolute top-6 left-6">
        <div className="text-[10px] tracking-[0.2em] text-white/30 uppercase font-mono">
          {time} UTC
        </div>
        {currentScene !== 'universe' && (
          <div className="text-[10px] tracking-wider text-cyan-400/40 mt-1 font-mono">
            SYSTEM ACTIVE
          </div>
        )}
      </div>

      {/* Top-right: Quick actions */}
      <div className="absolute top-6 right-6 flex gap-3 pointer-events-auto">
        {currentScene !== 'universe' && (
          <>
            <button
              onClick={toggleSearch}
              className="p-2 border border-white/15 rounded-lg text-white/40 hover:text-cyan-300 hover:border-cyan-400/30 transition-all backdrop-blur-md bg-black/20"
              title="Search"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </button>
            {selectedPlanet && (
              <button
                onClick={togglePlanetInfo}
                className="p-2 border border-white/15 rounded-lg text-white/40 hover:text-cyan-300 hover:border-cyan-400/30 transition-all backdrop-blur-md bg-black/20"
                title="Planet Info"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </button>
            )}
          </>
        )}
      </div>

      {/* Bottom-left: Controls hint */}
      <div className="absolute bottom-6 left-6">
        <div className="space-y-1 text-[10px] text-white/25 font-mono">
          <div>DRAG — Rotate</div>
          <div>SCROLL — Zoom</div>
          <div>CLICK — Select</div>
        </div>
      </div>

      {/* Bottom-right: Coordinates */}
      <div className="absolute bottom-6 right-6 text-right">
        <div className="text-[10px] text-white/20 font-mono">
          {currentScene === 'solarSystem' ? 'SOL-001' :
           currentScene === 'planetView' && selectedPlanet ? selectedPlanet.id.toUpperCase() + '-001' :
           currentScene === 'blackHole' ? 'BH-001' :
           currentScene === 'exoplanet' ? 'EXO-001' : 'UNI-001'}
        </div>
      </div>

      {/* Bottom-center: Galaxy zoom levels */}
      {currentScene === 'universe' && (
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2">
          <div className="flex items-center gap-1">
            {GALAXY_ZOOM_LEVELS.map((level, i) => (
              <div key={i} className="flex items-center">
                <div className="w-1.5 h-1.5 rounded-full bg-white/20" />
                {i < GALAXY_ZOOM_LEVELS.length - 1 && (
                  <div className="w-6 h-px bg-white/10" />
                )}
              </div>
            ))}
          </div>
          <div className="flex justify-between mt-1">
            {GALAXY_ZOOM_LEVELS.map((level, i) => (
              <div key={i} className="text-[8px] text-white/15 font-mono">{level}</div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

export function SearchPanel() {
  const { showSearch, toggleSearch, setSelectedPlanet, setScene, setTransitioning } = useUniverseStore()
  const [query, setQuery] = useState('')

  if (!showSearch) return null

  const filtered = PLANETS.filter(p =>
    p.name.toLowerCase().includes(query.toLowerCase())
  )

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="fixed top-20 right-6 z-50 w-72 pointer-events-auto"
    >
      <div className="rounded-xl border border-white/10 bg-black/50 backdrop-blur-xl overflow-hidden">
        <div className="p-3 border-b border-white/5">
          <input
            type="text"
            placeholder="Search celestial objects..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full bg-transparent text-white/80 text-sm placeholder-white/20 outline-none"
            autoFocus
          />
        </div>
        <div className="max-h-64 overflow-y-auto">
          {filtered.map((planet) => (
            <button
              key={planet.id}
              onClick={() => {
                setTransitioning(true)
                setTimeout(() => {
                  setSelectedPlanet(planet)
                  setScene('planetView')
                  toggleSearch()
                  setQuery('')
                }, 300)
              }}
              className="w-full flex items-center gap-3 p-3 hover:bg-white/5 transition-colors text-left"
            >
              <div
                className="w-3 h-3 rounded-full"
                style={{ backgroundColor: planet.color }}
              />
              <div>
                <div className="text-sm text-white/80">{planet.name}</div>
                <div className="text-[10px] text-white/30 capitalize">{planet.type} planet</div>
              </div>
            </button>
          ))}
          {query && filtered.length === 0 && (
            <div className="p-4 text-center text-xs text-white/30">No results found</div>
          )}
        </div>
      </div>
    </motion.div>
  )
}
