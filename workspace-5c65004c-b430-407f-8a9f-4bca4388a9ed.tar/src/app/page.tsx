'use client'

import { useEffect, useState } from 'react'
import { UniverseCanvas } from '@/components/universe/UniverseCanvas'
import { MainMenu, PlanetInfoPanel, HUD, SearchPanel } from '@/components/ui-overlay/UIOverlay'
import { useUniverseStore } from '@/store/useUniverseStore'

function LoadingScreen() {
  const [progress, setProgress] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          return 100
        }
        return prev + Math.random() * 15
      })
    }, 100)
    return () => clearInterval(interval)
  }, [])

  if (progress >= 100) return null

  return (
    <div className="fixed inset-0 z-[100] bg-black flex flex-col items-center justify-center">
      <div className="text-center">
        <h1 className="text-3xl font-extralight tracking-[0.5em] text-white/80 mb-2"
          style={{ fontFamily: 'var(--font-geist-sans)' }}
        >
          UNIVERSE EXPLORER
        </h1>
        <div className="w-48 h-px bg-white/10 mx-auto mb-6" />
        <div className="w-48 h-0.5 bg-white/5 rounded-full overflow-hidden mx-auto">
          <div
            className="h-full bg-cyan-400/60 rounded-full transition-all duration-200"
            style={{ width: `${Math.min(progress, 100)}%` }}
          />
        </div>
        <div className="mt-3 text-[10px] tracking-[0.3em] text-white/20 uppercase font-mono">
          Initializing systems...
        </div>
      </div>
    </div>
  )
}

export default function UniverseExplorer() {
  const [loaded, setLoaded] = useState(false)
  const { currentScene, selectedPlanet, showPlanetInfo } = useUniverseStore()

  useEffect(() => {
    // Show planet info automatically when entering planet view
    if (currentScene === 'planetView' && selectedPlanet) {
      useUniverseStore.getState().togglePlanetInfo()
    }
  }, [currentScene, selectedPlanet])

  useEffect(() => {
    const timer = setTimeout(() => setLoaded(true), 2000)
    return () => clearTimeout(timer)
  }, [])

  return (
    <main className="relative w-screen h-screen overflow-hidden bg-black">
      <LoadingScreen />

      {loaded && (
        <>
          <UniverseCanvas />
          <MainMenu />
          <PlanetInfoPanel />
          <HUD />
          <SearchPanel />
        </>
      )}
    </main>
  )
}
