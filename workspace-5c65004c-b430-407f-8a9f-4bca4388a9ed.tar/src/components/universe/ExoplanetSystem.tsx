'use client'

import { useRef, useMemo } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'

function Exoplanet() {
  const meshRef = useRef<THREE.Mesh>(null)
  const ringRef = useRef<THREE.Mesh>(null)

  const texture = useMemo(() => {
    const canvas = document.createElement('canvas')
    canvas.width = 2048
    canvas.height = 1024
    const ctx = canvas.getContext('2d')!

    // Alien landscape with purple and teal
    const gradient = ctx.createLinearGradient(0, 0, 0, 1024)
    gradient.addColorStop(0, '#4a1a6a')
    gradient.addColorStop(0.3, '#2a4a6a')
    gradient.addColorStop(0.6, '#1a3a5a')
    gradient.addColorStop(1, '#3a1a5a')
    ctx.fillStyle = gradient
    ctx.fillRect(0, 0, 2048, 1024)

    for (let i = 0; i < 100; i++) {
      const x = Math.random() * 2048
      const y = Math.random() * 1024
      const r = 10 + Math.random() * 50
      ctx.fillStyle = `rgba(${80 + Math.random() * 100}, ${40 + Math.random() * 60}, ${120 + Math.random() * 80}, 0.3)`
      ctx.beginPath()
      ctx.arc(x, y, r, 0, Math.PI * 2)
      ctx.fill()
    }

    return new THREE.CanvasTexture(canvas)
  }, [])

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.y += 0.003
    }
    if (ringRef.current) {
      ringRef.current.rotation.z = state.clock.elapsedTime * 0.1
    }
  })

  return (
    <group>
      <mesh ref={meshRef}>
        <sphereGeometry args={[4, 64, 64]} />
        <meshPhongMaterial map={texture} emissive="#2a1a4a" emissiveIntensity={0.2} />
      </mesh>
      <mesh ref={ringRef} rotation={[Math.PI / 3, 0, 0]}>
        <ringGeometry args={[5, 7, 128]} />
        <meshBasicMaterial
          color="#6644aa"
          transparent
          opacity={0.3}
          side={THREE.DoubleSide}
          depthWrite={false}
          blending={THREE.AdditiveBlending}
        />
      </mesh>
    </group>
  )
}

function BinaryStars() {
  const star1Ref = useRef<THREE.Mesh>(null)
  const star2Ref = useRef<THREE.Mesh>(null)

  useFrame((state) => {
    const t = state.clock.elapsedTime
    if (star1Ref.current) {
      star1Ref.current.position.x = Math.cos(t * 0.3) * 12
      star1Ref.current.position.z = Math.sin(t * 0.3) * 12
    }
    if (star2Ref.current) {
      star2Ref.current.position.x = Math.cos(t * 0.3 + Math.PI) * 12
      star2Ref.current.position.z = Math.sin(t * 0.3 + Math.PI) * 12
    }
  })

  return (
    <group>
      <pointLight position={[0, 5, 0]} intensity={2} distance={100} color="#ff8844" />
      <pointLight position={[0, -5, 0]} intensity={1.5} distance={80} color="#4488ff" />
      <mesh ref={star1Ref}>
        <sphereGeometry args={[1.5, 32, 32]} />
        <meshBasicMaterial color="#ff6622" />
      </mesh>
      <mesh ref={star2Ref}>
        <sphereGeometry args={[1, 32, 32]} />
        <meshBasicMaterial color="#4466ff" />
      </mesh>
    </group>
  )
}

function FloatingAsteroids() {
  const ref = useRef<THREE.Points>(null)
  const count = 300

  const positions = useMemo(() => {
    const pos = new Float32Array(count * 3)
    for (let i = 0; i < count; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 80
      pos[i * 3 + 1] = (Math.random() - 0.5) * 40
      pos[i * 3 + 2] = (Math.random() - 0.5) * 80
    }
    return pos
  }, [])

  useFrame((state) => {
    if (ref.current) {
      ref.current.rotation.y = state.clock.elapsedTime * 0.01
    }
  })

  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={count}
          array={positions}
          itemSize={3}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.3}
        color="#6a5a8a"
        transparent
        opacity={0.5}
        sizeAttenuation
      />
    </points>
  )
}

export function ExoplanetSystem() {
  return (
    <group>
      <ambientLight intensity={0.1} />
      <BinaryStars />
      <Exoplanet />
      <FloatingAsteroids />
    </group>
  )
}
