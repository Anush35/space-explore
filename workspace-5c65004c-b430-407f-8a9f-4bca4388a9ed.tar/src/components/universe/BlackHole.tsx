'use client'

import { useRef, useMemo } from 'react'
import { useFrame } from '@react-three/fiber'
import * as THREE from 'three'
import { useUniverseStore } from '@/store/useUniverseStore'

function AccretionDisk() {
  const ref = useRef<THREE.Mesh>(null)

  const diskTexture = useMemo(() => {
    const canvas = document.createElement('canvas')
    canvas.width = 1024
    canvas.height = 1024
    const ctx = canvas.getContext('2d')!

    ctx.clearRect(0, 0, 1024, 1024)

    for (let i = 0; i < 5000; i++) {
      const angle = Math.random() * Math.PI * 2
      const dist = 2 + Math.random() * 6
      const x = 512 + Math.cos(angle) * dist * 50
      const y = 512 + Math.sin(angle) * dist * 50

      const brightness = Math.max(0, 1 - dist / 8)
      const r = Math.floor(255 * brightness)
      const g = Math.floor(180 * brightness * brightness)
      const b = Math.floor(100 * brightness * brightness * brightness)
      const alpha = brightness * 0.6

      ctx.fillStyle = `rgba(${r}, ${g}, ${b}, ${alpha})`
      ctx.beginPath()
      ctx.arc(x, y, 1 + Math.random() * 3, 0, Math.PI * 2)
      ctx.fill()
    }

    return new THREE.CanvasTexture(canvas)
  }, [])

  useFrame((state) => {
    if (ref.current) {
      ref.current.rotation.z = state.clock.elapsedTime * 0.3
    }
  })

  return (
    <group>
      <mesh ref={ref} rotation={[Math.PI / 2.2, 0, 0]}>
        <ringGeometry args={[3, 10, 128]} />
        <meshBasicMaterial
          map={diskTexture}
          transparent
          opacity={0.8}
          side={THREE.DoubleSide}
          depthWrite={false}
          blending={THREE.AdditiveBlending}
        />
      </mesh>
      <mesh rotation={[Math.PI / 2.2 + 0.3, 0, 0]}>
        <ringGeometry args={[4, 12, 128]} />
        <meshBasicMaterial
          color="#ff4400"
          transparent
          opacity={0.1}
          side={THREE.DoubleSide}
          depthWrite={false}
          blending={THREE.AdditiveBlending}
        />
      </mesh>
    </group>
  )
}

function GravitationalLensing() {
  const ref = useRef<THREE.Mesh>(null)

  useFrame((state) => {
    if (ref.current) {
      const scale = 1 + Math.sin(state.clock.elapsedTime) * 0.05
      ref.current.scale.setScalar(scale)
    }
  })

  return (
    <mesh ref={ref}>
      <sphereGeometry args={[2.5, 64, 64]} />
      <meshBasicMaterial
        color="#001122"
        transparent
        opacity={0.9}
      />
    </mesh>
  )
}

function SwirlingParticles() {
  const ref = useRef<THREE.Points>(null)
  const count = 2000

  const [positions, velocities] = useMemo(() => {
    const pos = new Float32Array(count * 3)
    const vel = new Float32Array(count * 3)
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2
      const radius = 3 + Math.random() * 15
      const height = (Math.random() - 0.5) * 3
      pos[i * 3] = Math.cos(angle) * radius
      pos[i * 3 + 1] = height
      pos[i * 3 + 2] = Math.sin(angle) * radius

      vel[i * 3] = -Math.sin(angle) * 0.02
      vel[i * 3 + 1] = (Math.random() - 0.5) * 0.01
      vel[i * 3 + 2] = Math.cos(angle) * 0.02
    }
    return [pos, vel]
  }, [])

  useFrame(() => {
    if (!ref.current) return
    const posAttr = ref.current.geometry.getAttribute('position') as THREE.BufferAttribute
    const posArray = posAttr.array as Float32Array

    for (let i = 0; i < count; i++) {
      const i3 = i * 3
      const x = posArray[i3]
      const z = posArray[i3 + 2]
      const dist = Math.sqrt(x * x + z * z)

      const angle = Math.atan2(z, x) + 0.02 / Math.max(dist * 0.1, 0.5)
      posArray[i3] = Math.cos(angle) * dist
      posArray[i3 + 1] += velocities[i3 + 1]
      posArray[i3 + 2] = Math.sin(angle) * dist

      if (dist < 2.5) {
        const resetAngle = Math.random() * Math.PI * 2
        const resetDist = 8 + Math.random() * 7
        posArray[i3] = Math.cos(resetAngle) * resetDist
        posArray[i3 + 1] = (Math.random() - 0.5) * 3
        posArray[i3 + 2] = Math.sin(resetAngle) * resetDist
      }
    }
    posAttr.needsUpdate = true
  })

  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={count}
          array={positions}
          itemSize={3}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.1}
        color="#ff6622"
        transparent
        opacity={0.6}
        depthWrite={false}
        blending={THREE.AdditiveBlending}
        sizeAttenuation
      />
    </points>
  )
}

function WormholeEntrance() {
  const ref = useRef<THREE.Mesh>(null)
  const { setScene, setTransitioning } = useUniverseStore()

  useFrame((state) => {
    if (ref.current) {
      ref.current.rotation.z = state.clock.elapsedTime * 0.5
      const scale = 1.5 + Math.sin(state.clock.elapsedTime * 2) * 0.2
      ref.current.scale.setScalar(scale)
    }
  })

  return (
    <mesh
      ref={ref}
      position={[0, 0, -5]}
      onClick={() => {
        setTransitioning(true)
        setTimeout(() => setScene('exoplanet'), 1500)
      }}
    >
      <torusGeometry args={[1, 0.3, 32, 64]} />
      <meshBasicMaterial
        color="#8844ff"
        transparent
        opacity={0.6}
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </mesh>
  )
}

export function BlackHole() {
  return (
    <group>
      <ambientLight intensity={0.05} />
      <GravitationalLensing />
      <AccretionDisk />
      <SwirlingParticles />
      <WormholeEntrance />
    </group>
  )
}
