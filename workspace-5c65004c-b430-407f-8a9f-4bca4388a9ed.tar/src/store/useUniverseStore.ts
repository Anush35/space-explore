import { create } from 'zustand'

export type SceneType = 'universe' | 'solarSystem' | 'planetView' | 'hyperspace' | 'blackHole' | 'exoplanet' | 'galaxyZoom'

export interface PlanetData {
  id: string
  name: string
  color: string
  emissive?: string
  size: number
  orbitRadius: number
  orbitSpeed: number
  rotationSpeed: number
  description: string
  facts: string[]
  atmosphere?: string
  rings?: boolean
  ringColor?: string
  hasMoon?: boolean
  terrain?: string
  type: 'rocky' | 'gas' | 'ice'
}

interface UniverseState {
  currentScene: SceneType
  selectedPlanet: PlanetData | null
  isTransitioning: boolean
  cameraTarget: [number, number, number]
  showMenu: boolean
  showPlanetInfo: boolean
  showSearch: boolean
  galaxyZoomLevel: number
  freeFlyMode: boolean
  setScene: (scene: SceneType) => void
  setSelectedPlanet: (planet: PlanetData | null) => void
  setTransitioning: (val: boolean) => void
  setCameraTarget: (target: [number, number, number]) => void
  toggleMenu: () => void
  togglePlanetInfo: () => void
  toggleSearch: () => void
  setGalaxyZoomLevel: (level: number) => void
  setFreeFlyMode: (val: boolean) => void
}

export const useUniverseStore = create<UniverseState>((set) => ({
  currentScene: 'universe',
  selectedPlanet: null,
  isTransitioning: false,
  cameraTarget: [0, 0, 0],
  showMenu: true,
  showPlanetInfo: false,
  showSearch: false,
  galaxyZoomLevel: 0,
  freeFlyMode: false,
  setScene: (scene) => set({ currentScene: scene, isTransitioning: false }),
  setSelectedPlanet: (planet) => set({ selectedPlanet: planet }),
  setTransitioning: (val) => set({ isTransitioning: val }),
  setCameraTarget: (target) => set({ cameraTarget: target }),
  toggleMenu: () => set((s) => ({ showMenu: !s.showMenu })),
  togglePlanetInfo: () => set((s) => ({ showPlanetInfo: !s.showPlanetInfo })),
  toggleSearch: () => set((s) => ({ showSearch: !s.showSearch })),
  setGalaxyZoomLevel: (level) => set({ galaxyZoomLevel: level }),
  setFreeFlyMode: (val) => set({ freeFlyMode: val }),
}))
