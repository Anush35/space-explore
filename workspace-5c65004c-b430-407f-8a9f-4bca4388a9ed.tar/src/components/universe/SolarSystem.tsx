'use client'

import { useRef, useMemo, useState, useCallback } from 'react'
import { useFrame, useThree } from '@react-three/fiber'
import { Html, Ring } from '@react-three/drei'
import * as THREE from 'three'
import { useUniverseStore, PlanetData } from '@/store/useUniverseStore'
import { PLANETS } from '@/data/planets'

function Sun() {
  const meshRef = useRef<THREE.Mesh>(null)
  const glowRef = useRef<THREE.Mesh>(null)
  const lightRef = useRef<THREE.PointLight>(null)

  useFrame((state) => {
    if (!meshRef.current) return
    const time = state.clock.elapsedTime
    meshRef.current.rotation.y = time * 0.01

    if (glowRef.current) {
      const scale = 3.2 + Math.sin(time * 2) * 0.1
      glowRef.current.scale.setScalar(scale)
    }
  })

  return (
    <group>
      <pointLight ref={lightRef} intensity={3} distance={200} color="#fff5e0" />
      <pointLight intensity={1} distance={500} color="#ffaa44" position={[0, 0, 0]} />
      <mesh ref={meshRef}>
        <sphereGeometry args={[3, 64, 64]} />
        <meshBasicMaterial color="#ffcc44" />
      </mesh>
      <mesh ref={glowRef} scale={3.2}>
        <sphereGeometry args={[1, 32, 32]} />
        <meshBasicMaterial
          color="#ff8800"
          transparent
          opacity={0.15}
          depthWrite={false}
          blending={THREE.AdditiveBlending}
        />
      </mesh>
      <mesh scale={4.5}>
        <sphereGeometry args={[1, 32, 32]} />
        <meshBasicMaterial
          color="#ff4400"
          transparent
          opacity={0.05}
          depthWrite={false}
          blending={THREE.AdditiveBlending}
        />
      </mesh>
    </group>
  )
}

function Planet({ planet, onClick }: { planet: PlanetData; onClick: (planet: PlanetData) => void }) {
  const meshRef = useRef<THREE.Mesh>(null)
  const atmosphereRef = useRef<THREE.Mesh>(null)
  const orbitRef = useRef<THREE.Group>(null)
  const [hovered, setHovered] = useState(false)
  const moonRef = useRef<THREE.Mesh>(null)
  const ringsRef = useRef<THREE.Mesh>(null)

  useFrame((state) => {
    if (!orbitRef.current) return
    const time = state.clock.elapsedTime

    orbitRef.current.rotation.y = time * planet.orbitSpeed * 0.1

    if (meshRef.current) {
      meshRef.current.rotation.y += planet.rotationSpeed
    }

    if (planet.hasMoon && moonRef.current) {
      moonRef.current.position.x = Math.cos(time * 1.5) * (planet.size + 1.2)
      moonRef.current.position.z = Math.sin(time * 1.5) * (planet.size + 1.2)
      moonRef.current.position.y = Math.sin(time * 0.5) * 0.3
    }

    if (atmosphereRef.current) {
      atmosphereRef.current.rotation.y = time * 0.005
    }
  })

  const planetMaterial = useMemo(() => {
    if (planet.id === 'earth') {
      return new THREE.MeshPhongMaterial({
        color: planet.color,
        emissive: '#1a3a6a',
        emissiveIntensity: 0.15,
        shininess: 25,
      })
    }
    if (planet.id === 'jupiter' || planet.id === 'saturn') {
      return new THREE.MeshPhongMaterial({
        color: planet.color,
        emissive: planet.color,
        emissiveIntensity: 0.05,
        shininess: 10,
      })
    }
    return new THREE.MeshPhongMaterial({
      color: planet.color,
      emissive: planet.color,
      emissiveIntensity: 0.1,
      shininess: 15,
    })
  }, [planet])

  return (
    <group ref={orbitRef}>
      <group position={[planet.orbitRadius, 0, 0]}>
        <mesh
          ref={meshRef}
          onClick={(e) => {
            e.stopPropagation()
            onClick(planet)
          }}
          onPointerOver={(e) => {
            e.stopPropagation()
            setHovered(true)
            document.body.style.cursor = 'pointer'
          }}
          onPointerOut={() => {
            setHovered(false)
            document.body.style.cursor = 'auto'
          }}
          scale={hovered ? 1.15 : 1}
        >
          <sphereGeometry args={[planet.size, 64, 64]} />
          <primitive object={planetMaterial} attach="material" />
        </mesh>

        {planet.atmosphere && (
          <mesh ref={atmosphereRef} scale={planet.size * 1.15}>
            <sphereGeometry args={[1, 32, 32]} />
            <meshBasicMaterial
              color={planet.atmosphere}
              transparent
              opacity={0.1}
              depthWrite={false}
              side={THREE.BackSide}
            />
          </mesh>
        )}

        {hovered && (
          <Html center distanceFactor={20}>
            <div className="px-3 py-1.5 rounded-lg bg-black/70 backdrop-blur-md border border-cyan-500/30 text-cyan-300 text-sm font-mono whitespace-nowrap pointer-events-none">
              {planet.name}
            </div>
          </Html>
        )}

        {planet.rings && (
          <mesh ref={ringsRef} rotation={[Math.PI / 2.5, 0, 0]}>
            <ringGeometry args={[planet.size * 1.4, planet.size * 2.2, 128]} />
            <meshBasicMaterial
              color={planet.ringColor || '#d4c598'}
              transparent
              opacity={0.5}
              side={THREE.DoubleSide}
              depthWrite={false}
            />
          </mesh>
        )}

        {planet.hasMoon && (
          <mesh ref={moonRef}>
            <sphereGeometry args={[0.15, 16, 16]} />
            <meshPhongMaterial color="#c0c0c0" />
          </mesh>
        )}
      </group>
    </group>
  )
}

function OrbitLine({ radius }: { radius: number }) {
  const points = useMemo(() => {
    const pts = []
    for (let i = 0; i <= 128; i++) {
      const angle = (i / 128) * Math.PI * 2
      pts.push(new THREE.Vector3(Math.cos(angle) * radius, 0, Math.sin(angle) * radius))
    }
    return pts
  }, [radius])

  return (
    <line>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={points.length}
          array={new Float32Array(points.flatMap((p) => [p.x, p.y, p.z]))}
          itemSize={3}
        />
      </bufferGeometry>
      <lineBasicMaterial color="#1a3a5a" transparent opacity={0.3} />
    </line>
  )
}

function AsteroidBelt() {
  const ref = useRef<THREE.Points>(null)
  const count = 1500

  const positions = useMemo(() => {
    const pos = new Float32Array(count * 3)
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2
      const radius = 25 + (Math.random() - 0.5) * 3
      const y = (Math.random() - 0.5) * 1.5
      pos[i * 3] = Math.cos(angle) * radius
      pos[i * 3 + 1] = y
      pos[i * 3 + 2] = Math.sin(angle) * radius
    }
    return pos
  }, [])

  useFrame((state) => {
    if (ref.current) {
      ref.current.rotation.y = state.clock.elapsedTime * 0.01
    }
  })

  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={count}
          array={positions}
          itemSize={3}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.1}
        color="#8a7a6a"
        transparent
        opacity={0.6}
        sizeAttenuation
      />
    </points>
  )
}

export function SolarSystem() {
  const { setSelectedPlanet, setScene, setTransitioning } = useUniverseStore()

  const handlePlanetClick = useCallback((planet: PlanetData) => {
    setTransitioning(true)
    setTimeout(() => {
      setSelectedPlanet(planet)
      setScene('planetView')
    }, 500)
  }, [setSelectedPlanet, setScene, setTransitioning])

  return (
    <group>
      <Sun />
      {PLANETS.map((planet) => (
        <group key={planet.id}>
          <OrbitLine radius={planet.orbitRadius} />
          <Planet planet={planet} onClick={handlePlanetClick} />
        </group>
      ))}
      <AsteroidBelt />
      <ambientLight intensity={0.15} />
    </group>
  )
}
